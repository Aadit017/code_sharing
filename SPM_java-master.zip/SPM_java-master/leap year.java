import java.util.*; 

public class sort { 

    public static void main(String args[]) { 

    Scanner sc= new Scanner(System.in); 

    System.out.println("Enter the Year"); 

    int y=sc.nextInt(); 

    if(y%4==0) 

    { 

            System.out.println("It is a Leap Year"); 

    } 

    else 

    { 

            System.out.println("It is not a Leap Year"); 

 

    } 

    } 

} 

 
