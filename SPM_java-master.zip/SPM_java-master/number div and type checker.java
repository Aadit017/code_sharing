import java.util.*; 

public class div { 

    public static void main(String args[]) { 

      Scanner sc=new Scanner(System.in); 

      System.out.println("Enter limit of program"); 

      int n=sc.nextInt(); 

      System.out.println("Enter divisibility condition"); 

      int m=sc.nextInt(); 

      for(int i=1;i<n;i++) 

      { 

          if (i%m==0) 

          { 

          System.out.println(i); 

      { 

              if (i%2==0) 

              { 

              System.out.println("Even No."); 

              } 

              else if (i%3==0) 

              { 

              System.out.println("Odd No."); 

              } 

    } 

} 

}}} 
