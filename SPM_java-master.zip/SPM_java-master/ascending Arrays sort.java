import java.util.*; 

public class sort { 

    public static void main(String args[]) { 

    Scanner sc= new Scanner(System.in); 

     int aa[]={12,10,15}; 

     Arrays.sort(aa); 

System.out.println("Smallest Number= "+aa[0]); 

System.out.println("Next Higher Number= "+aa[1]); 

System.out.println("Highest Number= "+aa[2]); 

}} 
