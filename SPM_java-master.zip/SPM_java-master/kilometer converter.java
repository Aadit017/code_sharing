import java.util.*; 

class convert 

{ 

    void distances(double miles,double yard,double foot, double inch) 

    { 

        System.out.println("Miles="+1.609*miles); 

        System.out.println("Yard="+yard/1094); 

        System.out.println("foot="+foot/3281); 

        System.out.println("inch="+inch/39370); 

    } 

} 
